#!/bin/sh
rm -rf debug release ddr_debug ddr_release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
